#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);

    n = 0;
    m = 0;

    s = new see;

    client = new QMqttClient;

    client->setHostname("mqtt.yyzlab.com.cn");
    client->setPort(1883);
    client->connectToHost();


    connect(client,SIGNAL(messageReceived(QByteArray, QMqttTopicName)),this,SLOT(readMessage(QByteArray, QMqttTopicName)));
//    connect(&event,SIGNAL(lightTriggered),this,SLOT(guangzhaTriggered()));
//    connect(&event,SIGNAL(flameDetected),this,SLOT(huoyanDetected()));

    KeyBoard *keyborad = new KeyBoard;
    ui->lineEdit->installEventFilter(keyborad);
    ui->lineEdit_2->installEventFilter(keyborad);
    ui->lineEdit_3->installEventFilter(keyborad);
}

Form::~Form()
{
    delete ui;
}

void Form::on_pushButton_clicked()
{
    client->subscribe(ui->lineEdit->text());

}

void Form::on_pushButton_2_clicked()
{

    client->publish(ui->lineEdit_2->text(),ui->lineEdit_3->text().toUtf8());
}

void Form::readMessage(QByteArray buf,QMqttTopicName)
{
    ui->textEdit->append(QString(buf));

}


void Form::on_pushButton_3_clicked()
{


    if( n == 0)
    {
        led.on(fsmpLeds::LED1);
        led.on(fsmpLeds::LED2);
        led.on(fsmpLeds::LED3);
        client->publish(ui->lineEdit->text(), "{\"lamp\":true,\"id\":0}");

    }
   else
    {
        led.off(fsmpLeds::LED1);
        led.off(fsmpLeds::LED2);
        led.off(fsmpLeds::LED3);
        client->publish(ui->lineEdit->text(), "{\"light\":flase,\"id\":0}");
    }
    n = 0;



}

void Form::on_pushButton_4_clicked()
{
    beeper.start();
    beeper.setRate(2000);
    client->publish(ui->lineEdit->text(), "{\"alarm\":true,\"id\":0}");
}

void Form::on_pushButton_5_clicked()
{


     client->publish(ui->lineEdit->text(), "{\"tem\":true,\"id\":0}");
     temphum.temperature();
     client->publish(ui->lineEdit->text(), "{\"hum\":true,\"id\":0}");
     temphum.humidity();

}

void Form::on_pushButton_6_clicked()
{
    fan.start();
    fan.setSpeed(255);
    client->publish(ui->lineEdit->text(), "{\"fan\":true,\"id\":0}");


}


void Form::cameraCollect(QImage image)
{

    //QImage ->QPixmap
    QPixmap Pixmap = QPixmap::fromImage(image);
    ui->label->setPixmap(Pixmap);
    ui->label->setScaledContents(true);

}


void Form::on_pushButton_7_clicked()
{
      connect(&camera,SIGNAL(pixReady(QImage)),this,SLOT(cameraCollect(QImage)));
      camera.start();
      camera.setPixDelay(50);
}

//void Form::hongwaidetected(bool a)
//{
//    if(a)
//    {
//        ui->label_2->setText("有人");

//    }
//    else
//    {
//        ui->label_2->setText("无人");
//    }
//}

//void Form::huoyanDetected()
//{
//    if(m == 0)
//    {
//        ui->label->setText("有火");
//    }
//    else
//    {
//        ui->label->setText("无火");
//    }
//}

//void Form::guangzhaTriggered()
//{

//}

void Form::on_pushButton_8_clicked()
{
    connect(&event,SIGNAL(peopleDetected(bool)),this,SLOT(hongwaidetected(bool)));
    if( proximity.getValue())
    {

        client->publish(ui->lineEdit->text(), "{\"infrared\":true,\"id\":0}");
        client->publish(ui->lineEdit->text(), "{\"light\":true,\"id\":0}");

    }
    else
    {

        client->publish(ui->lineEdit->text(), "{\"infrared\":false,\"id\":0}");
        client->publish(ui->lineEdit->text(), "{\"false\":true,\"id\":0}");

    }


}



void Form::on_pushButton10_clicked()
{
    this->close();
}


void Form::on_pushButton_9_clicked()
{
    s->showFullScreen();
}

