#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    //ui->label->setText("这是label"); // 修改文本内容

    QPixmap pix;
    pix.load(":/1.jpg");
    ui->label->setPixmap(pix);
    ui->label->setScaledContents(true);

    // 设置文本
    //ui->lineEdit->setText("123");
    //ui->lineEdit_2->setText(ui->lineEdit->text() + "456");

    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
    ui->lineEdit->setPlaceholderText("请输入账号");
    ui->lineEdit_2->setPlaceholderText("请输入密码");
    ui->lineEdit_3->setEchoMode(QLineEdit::Password);
    ui->lineEdit_3->setPlaceholderText("请输入新密码");

    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(on_pushButton_2_clicked())); // 绑定按钮和触发函数

    KeyBoard *keyborad = new KeyBoard;
    ui->lineEdit->installEventFilter(keyborad);
    ui->lineEdit_2->installEventFilter(keyborad);
    ui->lineEdit_3->installEventFilter(keyborad);

    form = new Form();

    //ui->pushButton_2->setFlat(true); // 消除按钮边框
    //ui->pushButton->setIconSize(QSize(89, 25));

    this->setWindowIcon(QIcon(":/1.jpg"));
    socket = new QTcpSocket;
    socket->connectToHost(QHostAddress("192.168.7.197"), 1234);
    connect(socket, SIGNAL(connected()), this, SLOT(connectSuccess()));

}

Widget::~Widget()
{
    delete ui;

}

void Widget::connectSuccess()
{
    QMessageBox::about(this, "提示", "TCP服务器连接成功");
    connect(socket, SIGNAL(readyRead()), this, SLOT(messageRecived()));
}

void Widget::on_pushButton_2_clicked()
{
    this->close();
}

void Widget::messageRecived()
{
    char result[40] = {0};
    socket->read(result, 40);

//    printf("%s\n", result);

    if (0 == strcmp(result, "登录成功"))
    {
        QMessageBox::about(this, "提示", "登录成功");
        form->showFullScreen();
    }

    if (0 == strcmp(result, "注册成功，请重新登录"))
    {
        QMessageBox::about(this, "提示", "注册成功");
    }

    if (0 == strcmp(result, "注册失败，账号已存在"))
    {
        QMessageBox::about(this, "提示", "账号已存在");
    }

    if (0 == strcmp(result, "修改密码失败"))
    {
        QMessageBox::about(this, "提示", "请输入正确的原密码");
    }

    if (0 == strcmp(result, "修改密码成功"))
    {
        QMessageBox::about(this, "提示", "修改密码成功");
    }

    if (0 == strcmp(result, "账号或密码错误"))
    {
        QMessageBox::about(this, "提示", "请输入正确的账号和密码");
    }

    if (0 == strcmp(result, "账号注销成功"))
    {
        QMessageBox::about(this, "提示", "账号注销成功");
    }
}

void Widget::on_pushButton_clicked()
{
    char cmd[10] = "select";
    socket->write(cmd, 10);

    socket->write(ui->lineEdit->text().toStdString().c_str(), 40);
    socket->write(ui->lineEdit_2->text().toStdString().c_str(), 40);
}

void Widget::on_pushButton_3_clicked()
{
    char cmd[10] = "insert";
    socket->write(cmd, 10);

    socket->write(ui->lineEdit->text().toStdString().c_str(), 40);
    socket->write(ui->lineEdit_2->text().toStdString().c_str(), 40);
}

void Widget::on_pushButton_4_clicked()
{
    if (ui->lineEdit_3->text() != "")
    {
        char cmd[10] = "update";
        socket->write(cmd, 10);

        socket->write(ui->lineEdit->text().toStdString().c_str(), 40);
        socket->write(ui->lineEdit_2->text().toStdString().c_str(), 40);
        socket->write(ui->lineEdit_3->text().toStdString().c_str(), 40);
    }
    else QMessageBox::about(this, "提示", "新密码不能为空");


}

void Widget::on_pushButton_5_clicked()
{
    char cmd[10] = "delete";
    socket->write(cmd, 10);

    socket->write(ui->lineEdit->text().toStdString().c_str(), 40);
    socket->write(ui->lineEdit_2->text().toStdString().c_str(), 40);
}

