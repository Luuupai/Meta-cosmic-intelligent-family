#include "see.h"
#include "ui_see.h"

see::see(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::see)
{
    ui->setupUi(this);
    client = new QMqttClient;
        client->setHostname("mqtt.yyzlab.com.cn");
        client->setPort(1883);
        client->connectToHost();

        connect(client,SIGNAL(messageReceived(QByteArray,QMqttTopicName)),this,SLOT(readMessage(QByteArray,QMqttTopicName)));
        KeyBoard *keyboard = new KeyBoard();
        ui->lineEdit->installEventFilter(keyboard);
        ui->lineEdit_2->installEventFilter(keyboard);


        timer = new QTimer;
        timer->start(500);
        connect(timer,SIGNAL(timeout()),this,SLOT(Update()));
//            connect(timer,SIGNAL(timeout()),this,SLOT(prox));
//            connect(timer,SIGNAL(timeout()),this,SLOT(tem));
//            connect(timer,SIGNAL(timeout()),this,SLOT(hum));
}

see::~see()
{
    delete ui;
}

void see::on_pushButton_clicked()
{
    client->subscribe(ui->lineEdit->text());
}


void see::on_pushButton_2_clicked()
{
    client->publish(ui->lineEdit_2->text());
}

void see::readMessage(QByteArray buf,QMqttTopicName)
{
    QJsonDocument jd = QJsonDocument::fromJson(buf);
    QJsonObject jo = jd.object();
    if(jo.contains("light"))
    {
        QJsonValue jv1 = jo.value("light");
        ui->lineEdit_4->setText(QString::number((jv1.toDouble())));
    }
//    if(jo.contains("tem"))
//    {
//        QJsonValue jv2 = jo.value("tem");
//        ui->lineEdit_5->setText(QString::number((jv2.toDouble())));
//        QJsonValue jv3 = jo.value("hum");
//        ui->lineEdit_6->setText(QString::number((jv3.toDouble())));
//    }
    if(jo.contains("co2"))
    {
        QJsonValue jv4 = jo.value("co2");
        ui->lineEdit_7->setText(QString::number((jv4.toDouble())));
    }
    if(jo.contains("PM2.5"))
    {
        QJsonValue jv5 = jo.value("PM2.5");
        ui->lineEdit_8->setText(QString::number((jv5.toDouble())));
    }
    if(jo.contains("infrared"))
    {
        bool flame_state = jo.value("infrared").toBool();
                 if (flame_state)
                 {
                     QJsonValue jv6 = jo.value("infrared");
                     ui->lineEdit_9->setText("有人");
                 }
                 else
                 {
                     QJsonValue jv6 = jo.value("infrared");
                     ui->lineEdit_9->setText("无人");
                 }
    }
    if(jo.contains("flamGas"))
    {
        bool flame_state = jo.value("flamGas").toBool();
                 if (flame_state)
                 {
                     QJsonValue jv7 = jo.value("flamGas");
                     ui->lineEdit_10->setText("超标");
                 }
                 else
                 {
                     QJsonValue jv7 = jo.value("flamGas");
                     ui->lineEdit_10->setText("未超标");
                 }
    }
    if(jo.contains("sleet"))
    {
        bool flame_state = jo.value("sleet").toBool();
                 if (flame_state)
                 {
                     QJsonValue jv8 = jo.value("sleet");
                     ui->lineEdit_11->setText("有雨雪");
                 }
                 else
                 {
                     QJsonValue jv8 = jo.value("sleet");
                     ui->lineEdit_11->setText("无雨雪");
                 }
    }
//    if(jo.contains("smog"))
//    {
//        bool flame_state = jo.value("smog").toBool();
//                 if (flame_state)
//                 {
//                     QJsonValue jv9 = jo.value("smog");
//                     ui->lineEdit_12->setText("超标");
//                 }
//                 else
//                 {
//                     QJsonValue jv9 = jo.value("smog");
//                     ui->lineEdit_12->setText("未超标");
//                 }
//    }
}


void see::on_pushButton_3_clicked()
{
    this->close();
}

void see::Update()
{
    double light = fsmpLight().getValue();
    ui->lineEdit_4->setText(QString::number(light));
    double prox = fsmpProximity().getValue();
    ui->lineEdit_5->setText(QString::number(prox));
    double tem = fsmpTempHum().temperature();
    ui->lineEdit_6->setText(QString::number(tem));
    double hum = fsmpTempHum().humidity();
    ui->lineEdit_12->setText(QString::number(hum));

}
