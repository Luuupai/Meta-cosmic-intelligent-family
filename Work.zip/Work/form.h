#ifndef FORM_H
#define FORM_H

#include "keyboard.h"
#include <QWidget>
#include <QtMqtt/qmqttclient.h>
#include <fsmpFan.h>
#include <fsmpCamera.h>
#include <fsmpBeeper.h>
#include <fsmpLed.h>
#include <fsmpTempHum.h>
#include <fsmpEvents.h>
#include <fsmpProximity.h>
#include <fsmpLight.h>
#include <QPainter>
#include <QPicture>
#include <QPixmap>
#include "see.h"

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void readMessage(QByteArray buf,QMqttTopicName);

    void on_pushButton_3_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_7_clicked();

    void cameraCollect(QImage);

//    void hongwaidetected(bool);

    void on_pushButton_8_clicked();

//    void guangzhaTriggered();

//    void huoyanDetected();

    void on_pushButton10_clicked();

    void on_pushButton_9_clicked();

private:
    see *s;
    Ui::Form *ui;
    QMqttClient *client;
    fsmpFan fan;
    fsmpBeeper beeper;
    fsmpCamera camera;
    fsmpTempHum temphum;
    fsmpLeds led;
    fsmpEvents event;
    fsmpProximity proximity;
    int n,m;
};

#endif // FORM_H
