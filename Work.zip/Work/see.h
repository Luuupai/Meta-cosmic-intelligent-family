#ifndef SEE_H
#define SEE_H

#include <QWidget>
#include <QtMqtt/qmqttclient.h>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QMessageBox>
#include "keyboard.h"
#include "fsmpLight.h"
#include "fsmpProximity.h"
#include "fsmpTempHum.h"
#include <QTimer>

namespace Ui {
class see;
}

class see : public QWidget
{
    Q_OBJECT

public:
    explicit see(QWidget *parent = nullptr);
    ~see();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void readMessage(QByteArray buf,QMqttTopicName);

    void on_pushButton_3_clicked();

    void Update();

private:
    Ui::see *ui;
    QMqttClient *client;
    QTimer *timer;
};

#endif // SEE_H
